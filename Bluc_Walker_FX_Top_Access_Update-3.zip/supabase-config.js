/* Bluc Walker FX account configuration. Fill these two values from your Supabase project's API settings. Never put a service_role key here. */
window.BW_SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE";
window.BW_SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY_HERE";
