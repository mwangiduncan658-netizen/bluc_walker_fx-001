// BW 001 local trading journal and academy progress. Entries remain on this browser until a secure database is connected.
(() => {
  const storageKey = 'bwfx-journal-v1';
  const form = document.getElementById('journal-form');
  const list = document.getElementById('journal-list');
  if (form && list) {
    const read = () => { try { return JSON.parse(localStorage.getItem(storageKey) || '[]'); } catch (_) { return []; } };
    const write = entries => localStorage.setItem(storageKey, JSON.stringify(entries));
    const safe = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
    const render = () => {
      const entries = read(); list.replaceChildren();
      const count = entries.length, wins = entries.filter(e => Number(e.result) > 0).length;
      const total = entries.reduce((sum,e) => sum + (Number(e.result)||0), 0);
      const followed = entries.filter(e => e.followed === 'Yes').length;
      const byId = (id, value) => { const el=document.getElementById(id); if(el) el.textContent=value; };
      byId('j-count', String(count)); byId('j-win', count ? Math.round(wins/count*100)+'%' : '—'); byId('j-total', count ? (total>0?'+':'')+total.toFixed(2)+'R' : '—'); byId('j-plan', count ? Math.round(followed/count*100)+'%' : '—');
      const empty = document.getElementById('journal-empty'); if (empty) empty.hidden = count > 0;
      entries.slice().reverse().forEach(e => { const card=document.createElement('article'); card.className='journal-entry'; card.style.cssText='padding:14px;margin:10px 0;'; card.innerHTML=`<div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><strong>${safe(e.pair)} · ${safe(e.direction)}</strong><strong>${(Number(e.result)>0?'+':'')+Number(e.result||0).toFixed(2)}R</strong></div><small>${safe(e.date)} · ${safe(e.timeframe)} · ${safe(e.emotion)}</small><p style="margin-top:7px">${safe(e.setup || 'No setup note')}</p><small>Plan followed: ${safe(e.followed)}${e.notes ? ' · Lesson: '+safe(e.notes) : ''}</small>`; list.appendChild(card); });
    };
    const dateField=form.elements.namedItem('date'); if(dateField && !dateField.value) dateField.value = new Date().toISOString().slice(0,10);
    form.addEventListener('submit', event => { event.preventDefault(); const data = new FormData(form); const pair=String(data.get('pair')||'').trim().toUpperCase(); if(!pair){ const err=form.querySelector('.calc-error'); if(err){err.hidden=false;err.textContent='Enter the instrument, for example XAUUSD.';} return; }
      const entries=read(); entries.push({id:Date.now(),date:data.get('date')||'',pair,direction:data.get('direction'),timeframe:data.get('timeframe'),entry:data.get('entry'),sl:data.get('sl'),tp:data.get('tp'),result:data.get('result')||0,setup:data.get('setup')||'',emotion:data.get('emotion'),followed:data.get('followed'),notes:data.get('notes')||''}); write(entries); form.reset(); if(dateField) dateField.value=new Date().toISOString().slice(0,10); render(); const err=form.querySelector('.calc-error'); if(err) err.hidden=true;
    });
    const clear=document.getElementById('j-clear'); if(clear) clear.addEventListener('click',()=>{if(confirm('Clear all saved journal entries from this browser?')){write([]);render();}});
    const exportBtn=document.getElementById('j-export'); if(exportBtn) exportBtn.addEventListener('click',()=>{const entries=read(); if(!entries.length){alert('Add a journal entry before exporting.');return;} const cols=['date','pair','direction','timeframe','entry','sl','tp','result','setup','emotion','followed','notes']; const csv=[cols.join(','),...entries.map(e=>cols.map(k=>'"'+String(e[k]??'').replace(/"/g,'""')+'"').join(','))].join('\r\n'); const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8;'})); const a=document.createElement('a');a.href=url;a.download='bluc-walker-fx-journal.csv';a.click();URL.revokeObjectURL(url);});
    render();
  }
  const progressKey='bwfx-academy-progress-v1'; const checks=[...document.querySelectorAll('[data-topic]')];
  if(checks.length){let saved={};try{saved=JSON.parse(localStorage.getItem(progressKey)||'{}')}catch(_){}; const update=()=>{let done=0;checks.forEach(c=>{c.checked=!!saved[c.dataset.topic];if(c.checked)done++;});const count=document.getElementById('progress-count');if(count)count.textContent=done+'/'+checks.length;localStorage.setItem(progressKey,JSON.stringify(saved));}; checks.forEach(c=>c.addEventListener('change',()=>{saved[c.dataset.topic]=c.checked;update();}));update();}
})();
