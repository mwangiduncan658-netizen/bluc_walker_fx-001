// Bluc Walker FX: mobile navigation, market selector and Supabase authentication.
(() => {
  const menu = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.nav');
  if (menu && nav) {
    menu.addEventListener('click', () => { const open = nav.classList.toggle('open'); menu.setAttribute('aria-expanded', String(open)); });
    nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => { nav.classList.remove('open'); menu.setAttribute('aria-expanded','false'); }));
  }
  const symbol = document.getElementById('market-symbol');
  const chart = document.getElementById('market-chart');
  const marketTitle = document.getElementById('market-title');
  const labels = {'OANDA:XAUUSD':'Gold · XAUUSD','OANDA:EURUSD':'EUR/USD','OANDA:GBPUSD':'GBP/USD','OANDA:USDJPY':'USD/JPY','BINANCE:BTCUSDT':'Bitcoin · BTC/USDT'};
  if (symbol && chart) symbol.addEventListener('change', () => {
    const value = symbol.value; if (marketTitle) marketTitle.textContent = labels[value] || value;
    const url = new URL('https://www.tradingview.com/widgetembed/');
    url.searchParams.set('frameElementId','tradingview_chart'); url.searchParams.set('symbol',value); url.searchParams.set('interval','60');
    url.searchParams.set('hidesidetoolbar','0'); url.searchParams.set('symboledit','1'); url.searchParams.set('saveimage','0'); url.searchParams.set('toolbarbg','#ffffff');
    url.searchParams.set('studies','[]'); url.searchParams.set('theme','light'); url.searchParams.set('style','1'); url.searchParams.set('timezone','Etc/UTC'); url.searchParams.set('withdateranges','1'); url.searchParams.set('hideideas','1'); url.searchParams.set('locale','en'); chart.src = url.toString();
  });
  const form = document.getElementById('auth-form');
  if (!form) return;
  const msg = document.getElementById('auth-message'); const nameWrap = document.getElementById('name-field-wrap');
  const nameInput = document.getElementById('auth-name'); const emailInput = document.getElementById('auth-email'); const passInput = document.getElementById('auth-password');
  const submit = document.getElementById('auth-submit'); const reset = document.getElementById('auth-reset'); const memberStatus = document.getElementById('member-status');
  let mode = 'signup'; let client = null;
  const configured = () => window.BW_SUPABASE_URL && window.BW_SUPABASE_ANON_KEY && !window.BW_SUPABASE_URL.includes('PASTE_') && !window.BW_SUPABASE_ANON_KEY.includes('PASTE_');
  function setMessage(text, kind='') { msg.textContent = text; msg.className = 'auth-message' + (kind ? ' ' + kind : ''); }
  function setMode(next) { mode = next; document.querySelectorAll('[data-auth-mode]').forEach(b => b.classList.toggle('active', b.dataset.authMode === mode)); nameWrap.hidden = mode === 'login'; nameInput.required = mode === 'signup'; passInput.autocomplete = mode === 'login' ? 'current-password' : 'new-password'; submit.textContent = mode === 'login' ? 'Log in securely' : 'Create my account'; setMessage(configured() ? 'Ready. Use your email and password to continue.' : 'Account service is not connected yet. Supabase setup is required before real accounts can be created.'); }
  document.querySelectorAll('[data-auth-mode]').forEach(b => b.addEventListener('click', () => setMode(b.dataset.authMode)));
  if (configured() && window.supabase?.createClient) client = window.supabase.createClient(window.BW_SUPABASE_URL, window.BW_SUPABASE_ANON_KEY);
  if (client) { client.auth.getSession().then(({data}) => { if (data?.session) showSignedIn(data.session.user); }); client.auth.onAuthStateChange((_event, session) => { if (session) showSignedIn(session.user); }); }
  function showSignedIn(user) { memberStatus.hidden = false; memberStatus.replaceChildren(); const line = document.createElement('p'); line.textContent = 'Signed in as ' + (user.email || 'member') + '.'; const out = document.createElement('button'); out.type = 'button'; out.textContent = 'Log out'; out.addEventListener('click', async () => { const {error} = await client.auth.signOut(); if (error) setMessage(error.message, 'error'); else { memberStatus.hidden = true; setMessage('You have logged out successfully.', 'success'); } }); memberStatus.append(line,out); setMessage('Your account session is active.', 'success'); submit.hidden = true; }
  if (reset) reset.addEventListener('click', async () => {
    if (!client) { setMessage('Password reset will work after the Supabase account service is connected.', 'error'); return; }
    const email = emailInput.value.trim(); if (!email) { setMessage('Enter your email address first, then tap Forgot password again.', 'error'); return; }
    try { const {error} = await client.auth.resetPasswordForEmail(email, {redirectTo: window.location.origin}); if (error) setMessage(error.message, 'error'); else setMessage('Password reset email sent if this address has an account. Check your inbox.', 'success'); } catch (_) { setMessage('Could not send the reset email. Check your connection and Supabase settings.', 'error'); }
  });
  form.addEventListener('submit', async event => { event.preventDefault(); if (!client) { setMessage('To activate real registration and login, the site owner must connect a Supabase project. This form will not pretend to create an account before that setup.', 'error'); return; }
    submit.disabled = true; submit.textContent = mode === 'login' ? 'Signing in…' : 'Creating account…';
    try { let result; if (mode === 'signup') result = await client.auth.signUp({email: emailInput.value.trim(), password: passInput.value, options:{data:{full_name:nameInput.value.trim()}}}); else result = await client.auth.signInWithPassword({email:emailInput.value.trim(), password:passInput.value});
      if (result.error) setMessage(result.error.message, 'error'); else if (mode === 'signup' && !result.data.session) setMessage('Account request submitted. Check your email for the confirmation link, then log in.', 'success'); else if (result.data.user) showSignedIn(result.data.user);
    } catch (_) { setMessage('Could not reach the account service. Check your internet connection and Supabase settings.', 'error'); }
    finally { submit.disabled = false; submit.textContent = mode === 'login' ? 'Log in securely' : 'Create my account'; }
  });
  setMode('signup');
})();
