BLUC WALKER FX — PROFESSIONAL WEBSITE UPGRADE

STYLE: Clean professional white, royal purple and green.

INCLUDED FEATURES
- Responsive homepage and original Bluc Walker FX branding/assets.
- TradingView chart panel with market selector (XAUUSD, EURUSD, GBPUSD, USDJPY and BTC/USDT). Chart availability/data timing depends on TradingView and its providers.
- Create-account and login interface, including password-reset request flow.
- Trading journal: save practice trades locally in the current browser, calculate entry count/win rate/total R/plan-following rate, and export CSV.
- FX Academy topics and saved learning progress in the current browser.

IMPORTANT ACCOUNT / PRIVACY NOTES
Real accounts and password reset do not work until the owner connects a Supabase project. The journal and Academy progress currently save only in the browser/device being used. They are not synced to other devices or uploaded to an account. Do not describe these as cloud-synced until a secure database integration is completed.

TO ACTIVATE REAL ACCOUNTS (one-time setup)
1. Create a project at https://supabase.com/ and open Project Settings > API (or API Keys).
2. Copy the Project URL and publishable/anon public key.
3. Edit supabase-config.js and replace the two PASTE_... values.
4. In Supabase Authentication settings, configure the site URL and add the Netlify URL to allowed redirect URLs. Configure email confirmation as desired.
5. Never put a service_role key or secret key in this website.
6. Test registration, email confirmation, login, logout and password reset after deploying.

DEPLOY TO NETLIFY
1. Download and extract this ZIP on a computer or phone that can extract ZIP files.
2. Open the extracted folder and confirm index.html, styles.css, script.js, supabase-config.js, member-tools.js, README.txt and the assets folder are together.
3. In Netlify, open the existing Bluc Walker site and use the manual deploy / deploy files area to upload the extracted site folder contents. Do not upload the ZIP itself if the Netlify deploy page expects extracted files.
4. Wait for deploy to finish, then open the live site and test on phone.

This package does not update the live Netlify website automatically. It is an educational platform, not a broker or a financial-advice service.

LATEST LAYOUT UPDATE (21 OCT 2026)
- Create Account and Monitor Market buttons are now in the top hero area.
- The Live Market + Member Account section has been moved near the top of the page, immediately after the hero/brand line.
- Header navigation includes direct shortcuts to Monitor Market and Create Account.
- This is a website package update only; it does not publish itself to the live Netlify site.
